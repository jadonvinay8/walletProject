package com.cg;

import java.util.*;

public class Demo1 {

	public static void main(String[] args) {
		// Non-generic collection. set is unordered
		
		Set set = new HashSet<>();
		set.add("ram");
		set.add("sham");
		set.add("abdul");
		set.add(55);              //autoboxing
		set.add(null);
		set.add("ganesh");
		set.add("ram");
		System.out.println(set);
		System.out.println(set.size());

		
	}

}
