package com.cg;


import java.util.*;

public class Demo3 {

	public static void main(String[] args) {
		// LinkedHashSet maintains insertion order(linked) but no duplicates
		
		Set<String> set = new LinkedHashSet<String>();
		
		set.add("ram");
		set.add("sham");
		set.add("abdul");
	  //set.add(55);
		set.add(null);
		set.add("ganesh");
		set.add("ram");
		System.out.println(set);
		System.out.println(set.size());
	}

}
