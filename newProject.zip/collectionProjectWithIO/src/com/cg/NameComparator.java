package com.cg;

import java.util.*;
import com.cg.bean.*;

public class NameComparator implements Comparator<Account> {

	@Override
	public int compare(Account a, Account b) {
		// 
		return a.getAccountHolder().compareTo(b.getAccountHolder());
	}

}
