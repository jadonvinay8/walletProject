package com.cg;

import java.io.*;
import java.util.*;
import com.cg.bean.*;
import com.cg.service.Validator;

public class Demo8 {

	public static void main(String[] args) throws IOException {
		
		Map<String, Account> accMap = new TreeMap<String, Account>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int choice = 0;
		String read;
		
		while(true) {
			System.out.println("menu");
			System.out.println("================");
			System.out.println("1. create new account");
			System.out.println("2. print all accounts");
			System.out.println("3. exit");
			System.out.println("enter your choice ");
			
			read = br.readLine();
			choice = Integer.parseInt(read);
			
			switch(choice) {
				case 1:
					long number = 0L;
					double bal = 0.00;
					
					//accepting and validating account number
					System.out.println("enter account number");
					while(true) {
						String s_id = br.readLine();
						boolean b1 = Validator.validateData(s_id, Validator.aidPattern);
						if(b1) {
							try {
								int id = Integer.parseInt(s_id);
								break;
							}
							catch(NumberFormatException e) {
								System.out.println("Account number must be numeric. re-enter");
							}
						
						}
						else
							System.out.println("re enter account number in 3 digits ");
					}
					
					//accepting and validating phone
					System.out.println("enter mobile number");
					while(true) {
						String s_mb = br.readLine();
						boolean b1 = Validator.validateData(s_mb, Validator.phonePattern);
						if(b1) {
							try {
								number = Long.parseLong(s_mb);
								break;
							}
							catch(NumberFormatException e) {
								System.out.println("phone number must be numeric. re-enter");
							}
						
						}
						else
							System.out.println("re enter phone number in 10 digits ");
					}
					
					//accepting and validating name
					System.out.println("enter account holder name: ");
					while(true) {
						String s_name = br.readLine();
						boolean b1 = Validator.validateData(s_name, Validator.namePattern);
						if(b1) 
							break;
						else
							System.out.println("re enter name in alphabets ");
					}
					
					//accepting and validating balance
					System.out.println("enter balance: ");
					while(true) {
						String s_bal = br.readLine();
						boolean b1 = Validator.validateData(s_bal, Validator.balPattern);
						if(b1) {
							try {
								bal = Double.parseDouble(s_bal);
								break;
							}
							catch(NumberFormatException e) {
								System.out.println("balance cant be negative. re-enter");
							}
						
						}
						else
							System.out.println("re enter phone number in 10 digits ");
					}
					
					break;
					
				case 2:
					
					Collection<Account> vc = accMap.values();
					List<Account> accList = new ArrayList<Account>(vc);
					Collections.sort(accList);
					for(Account a: accList)
						System.out.println(a); //service.printStatement
					
					break;
					
				case 3:
					
					System.out.println("exiting program");
					System.exit(0);
				
				default:
					System.out.println("invalid choice");
			}

		}
		
		/*
		System.out.println(accMap);
		System.out.println();

		System.out.println(accMap.keySet());
		
		Collection<Account> vals = accMap.values();
		List<Account> accList = new ArrayList<Account>(vals);
		Collections.sort(accList);     //sort by id
		
		for(Account a: accList)
			System.out.println(a);
		System.out.println();

		
		//sort by name
		Comparator nc = new NameComparator();
		Collections.sort(accList, nc);
		for(Account a: accList)
			System.out.println(a);
		System.out.println();

		
		//sort by balance
		Comparator bc = new BalanceComparator();
		Collections.sort(accList, bc);
		for(Account a: accList)
			System.out.println(a);
		
		*/
		
	}

}
